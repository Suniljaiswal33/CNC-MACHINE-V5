"""
================================================================================
  LCD Cover v3 — build123d Parametric Model
================================================================================
  Dimensions  : 710 x 1344 x 177 mm  →  scaled 0.1x  →  71 x 134.4 x 17.7 mm
  Version     : v3
================================================================================

  Geometry Build Sequence:
  ─────────────────────────
  1. Base solid        — 710 × 1344 × 177 mm box
  2. Vertical fillet   — R80 on 4 vertical (Z-axis) corner edges
  3. Shell             — 30 mm uniform walls, top face open
  4. Bottom fillet     — R47 on 4 outer bottom perimeter edges
  5. Through-cut       — Rectangular LCD window, top-down
  6. Chamfer 29 mm     — 4 inner bottom edges → inward bevel
  7. Text deboss       — "REFLOW OVEN" on bottom face
  8. Uniform Scale     — 0.1x applied to complete object

  ── TEXT CONTROLS ─────────────────────────────────────────────────────────────
  TEXT_SIZE       — Font height in mm      ↑ increase = bigger text
  TEXT_DEPTH      — Engraving depth in mm  ↑ increase = deeper groove
  TEXT_LINE_GAP   — Gap between two line centres in mm
  TEXT_CX / CY    — X / Y centre of text block on bottom face
"""

# ── Imports ────────────────────────────────────────────────────────────────────
from build123d import *
from pathlib import Path
from ocp_vscode import show, set_port, reset_show

# ── OCP CAD Viewer ─────────────────────────────────────────────────────────────
set_port(3939)
reset_show()

# ── Design Parameters ──────────────────────────────────────────────────────────
LENGTH          = 710    # mm
WIDTH           = 1344   # mm
HEIGHT          = 177    # mm
CORNER_RADIUS   = 80     # mm — vertical corner fillet
BOTTOM_RADIUS   = 47     # mm — outer bottom fillet
WALL_THICKNESS  = 30     # mm — shell wall thickness
CHAMFER_SIZE    = 29     # mm — inner bottom chamfer
SCALE_FACTOR    = 0.1    # uniform scale applied to final object

# ── Text Controls — Edit These ─────────────────────────────────────────────────
TEXT_LINE1      = "REFLOW"  # first line
TEXT_LINE2      = "OVEN"    # second line
TEXT_SIZE       = 95        # mm — font height  (try 30 – 80)
TEXT_DEPTH      = 8         # mm — engrave depth (try 2 – 6)
TEXT_LINE_GAP   = 80        # mm — spacing between line centres (try 20 – 60)
TEXT_CX         = 0         # mm — X shift on bottom face  (0 = centred)
TEXT_CY         = -467      # mm — Y centre of text block

# ── LCD Window Cutout Corner Points ───────────────────────────────────────────
CUT_POINTS = [
    ( 244.8291,  439.7868),
    (-244.3703,  439.7868),
    (-244.3703, -310.3095),
    ( 244.8291, -310.3095),
]
_xs   = [p[0] for p in CUT_POINTS]
_ys   = [p[1] for p in CUT_POINTS]
CUT_W  = max(_xs) - min(_xs)
CUT_H  = max(_ys) - min(_ys)
CUT_CX = (max(_xs) + min(_xs)) / 2
CUT_CY = (max(_ys) + min(_ys)) / 2

# ── Step 1: Base Solid ─────────────────────────────────────────────────────────
body = Box(LENGTH, WIDTH, HEIGHT,
           align=(Align.CENTER, Align.CENTER, Align.MIN))

# ── Step 2: Vertical Corner Fillets (R80) ──────────────────────────────────────
body = fillet(body.edges().filter_by(Axis.Z), CORNER_RADIUS)

# ── Step 3: Shell — Open Top Face ─────────────────────────────────────────────
top_face = body.faces().sort_by(Axis.Z)[-1]
body = offset(body, amount=-WALL_THICKNESS, openings=top_face)

# ── Step 4: Outer Bottom Perimeter Fillet (R47) ────────────────────────────────
bottom_perimeter_edges = body.edges().filter_by(GeomType.LINE).sort_by(Axis.Z)[:4]
body = fillet(bottom_perimeter_edges, BOTTOM_RADIUS)

# ── Step 5: Rectangular Through-Cut — Top to Bottom ───────────────────────────
with BuildPart() as _bp:
    add(body)
    with Locations((CUT_CX, CUT_CY, HEIGHT + 5)):
        Box(CUT_W, CUT_H, HEIGHT + 10,
            align=(Align.CENTER, Align.CENTER, Align.MAX),
            mode=Mode.SUBTRACT)
body = _bp.part

# ── Step 6: Chamfer 29 mm ─────────────────────────────────────────────────────
inner_bottom_cut_edges = [
    e for e in body.edges().filter_by(GeomType.LINE)
    if abs((e.bounding_box().min.Z + e.bounding_box().max.Z) / 2) < 2
    and abs(e.bounding_box().center().X) < 280
    and abs(e.bounding_box().center().Y) < 480
]
body = chamfer(inner_bottom_cut_edges, CHAMFER_SIZE)

# ── Step 7: "REFLOW OVEN" Debossed Text — Bottom Face ─────────────────────────
text_plane = Plane(
    origin  = (TEXT_CX, TEXT_CY, 0),
    x_dir   = (-1, 0, 0),   # mirror X → correct orientation on bottom face
    z_dir   = (0,  0, -1)   # normal down → extrude -depth into floor
)

with BuildPart() as _bp2:
    add(body)
    with BuildSketch(text_plane):
        with Locations((0, +TEXT_LINE_GAP / 2)):
            Text(TEXT_LINE1, font_size=TEXT_SIZE,
                 align=(Align.CENTER, Align.CENTER))
        with Locations((0, -TEXT_LINE_GAP / 2)):
            Text(TEXT_LINE2, font_size=TEXT_SIZE,
                 align=(Align.CENTER, Align.CENTER))
    extrude(amount=-TEXT_DEPTH, mode=Mode.SUBTRACT)

body = _bp2.part

# ── Step 8: Uniform Scale 0.1x ────────────────────────────────────────────────
# Scale the complete finished object uniformly by SCALE_FACTOR.
# All dimensions, fillets, chamfers and text scale proportionally.
# Result: 710 → 71 mm, 1344 → 134.4 mm, 177 → 17.7 mm
body = scale(body, by=SCALE_FACTOR)

bb = body.bounding_box()
print(f"Scaled dimensions: "
      f"{bb.max.X - bb.min.X:.2f} x "
      f"{bb.max.Y - bb.min.Y:.2f} x "
      f"{bb.max.Z - bb.min.Z:.2f} mm")

# ── Step 9: Visualise in OCP CAD Viewer ───────────────────────────────────────
show(body, names=["LCD Cover v3"],
     colors=["#7A8FA0"], alphas=[1.0], reset_camera=True)

# ── Step 10: Export STL to Desktop ────────────────────────────────────────────
desktop = Path.home() / "Desktop"
desktop.mkdir(exist_ok=True)
output_path = desktop / "LCD cover v3.stl"

exporter = Mesher()
exporter.add_shape(body)
exporter.write(str(output_path))

# ── Summary ───────────────────────────────────────────────────────────────────
print("=" * 60)
print("  LCD Cover v3 — Export Summary")
print("=" * 60)
print(f"  Output file  : {output_path}")
print(f"  File size    : {output_path.stat().st_size / 1024:.1f} KB")
print(f"  Volume       : {body.volume:,.4f} mm³")
print(f"  Scale        : {SCALE_FACTOR}x  (original 710×1344×177)")
print(f"  Final size   : {bb.max.X-bb.min.X:.2f} x "
                        f"{bb.max.Y-bb.min.Y:.2f} x "
                        f"{bb.max.Z-bb.min.Z:.2f} mm")
print(f"  Text         : '{TEXT_LINE1} / {TEXT_LINE2}'")
print(f"  Text size    : {TEXT_SIZE} mm  → scaled: {TEXT_SIZE*SCALE_FACTOR:.1f} mm")
print(f"  Text depth   : {TEXT_DEPTH} mm → scaled: {TEXT_DEPTH*SCALE_FACTOR:.2f} mm")
print("=" * 60)